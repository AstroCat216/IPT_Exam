var sign = document.querySelector(".sign");
var log = document.querySelector(".login");
var fname = document.getElementById('fname');
var lname = document.getElementById('lname');
var user = document.getElementById('user');
var pass = document.getElementById('pass');

window.onload = addEventListener();


function addEventListener(){
	if (window.addEventListener) {
		var x = document.getElementById("close").addEventListener('click',close_modal,false);
	}
	if (window.addEventListener) {
		var open = document.getElementById('signup').addEventListener('click',open_modal,false);
	}
	if (window.addEventListener) {
		var open = document.getElementById('login').addEventListener('click',login,false);
	}
	if (window.addEventListener) {
		var open = document.getElementById('close1').addEventListener('click',close_log,false);
	}

}

function close_log(){
	log.classList.remove('bg-active');
}

function login(){
	log.classList.add('bg-active');
}

function open_modal(){
	sign.classList.add('bg-active');
	console.log('wd');
}


function close_modal(){
	sign.classList.remove('bg-active');
	console.log('dwad');
}

function off_modal(){
	alert('dawd');
}