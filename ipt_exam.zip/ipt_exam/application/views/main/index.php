<!-- View -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Crud System</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/dashboard.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/modal.css'); ?>">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Roboto&display=swap" rel="stylesheet">
	<script src="<?php echo base_url('assets/js/fontawesome.js') ?>" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/js/jquery.js') ?>" type="text/javascript"></script>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-secondary">
	<div class="container">
		<a class="text-light nav-link fs-4" href="<?php echo base_url('main/index')?>">CRUD</a>
		<div class="d-flex">
			<div class="col-md-12">
				<a id="signup" title="Add Data" class="btn btn-primary">Add Data</a>
			</div>
		</div>
	</div>
</nav>

<!-- section -->
	<section>
		<div class="content">
			<!-- <a href="edit">Edit</a> -->
		</div>
	</section>
<!-- end of section -->

<!-- data -->
<div class="table-data">
                <div class="container col-md-12 col-sm-12 table-responsive">
                    <table id="table_date_page" class="table table-success" style="width:100%">
                        <div class="col-md-12 mb-2">
                           <div class="d-flex justify-content-between">
                                
                            </div>
       
                        <thead class="tbl-head">
                            <tr class="table-danger container border">
                                <th scope="col" class="text-center">First Name</th>
                                <th scope="col" class="text-center">Last Name</th>
                                <th scope="col" class="text-center">Email</th>
                                <th scope="col" class="text-center">Edit</th>
                                <th scope="col" class="text-center">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
								if ($datas) {
									foreach ($datas as $data) {
									    ?>
									    <tr align="center">
									    	
									    	<td class="text-dark"><?php echo $data->fname; ?></td>
									    	<td class="text-dark"><?php echo $data->lname; ?></td>
									    	<td class="text-dark"><?php echo $data->email; ?></td>
									    	
									    	<td><a class="nav-link btn btn-secondary text-light w-50 font"  href="<?php echo base_url('main/edit/' .$data->id); ?>" id="edit"><i class="fas fa-edit me-1"></i> Edit</a></td>
									    	<td><a class="nav-link btn btn-danger text-light w-50 font" href="<?php echo base_url('main/delete/' .$data->id); ?>" id="delete" onclick="return confirm('Do you want to Delete this?')"><i class="fas fa-trash me-1"></i> Delete</a></td>
									    </tr>
									    <?php
									}
								}
							?>
                        </tbody>
                    </table>
                       
                    </div> 
                </div>
<!-- end of data -->

<!-- signup -->
	<div class="sign">
		<div class="container w-50">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="col-md-12">
                        <h3 class="text-left modal-title fw-bold">Register Data</h3>
                    </div>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url('main/sign') ?>" method="POST" autocomplete="off" class="form-group">
                        
                        <div class="mb-7">
                            <label for="" class="form-label">
                                First Name:
                            </label>
                    
                            <input type="text" name="fname" required placeholder="First Name" class="form-control">
                        </div>
                         <div class="mb-7">
                            <label for="" class="form-label">
                                Last Name:
                            </label>
                            <input type="text" name="lname" required placeholder="Last Name" class="form-control">
                        </div>
                         <div class="mb-7" class="form-label">
                            <label for="">
                               Email:
                            </label>
                            <input type="text"  name="email" required placeholder="Email" class="form-control">
                        </div>
                        <div class="mb-7" class="form-label">
                            <label for="">
                                Password
                            </label>
                            <input type="password" name="password" required placeholder="Password" class="form-control">
                        </div>
                        <br>
                        <div class="col-md-12" class="form-label">
                            <button type="submit" name="register" class="btn btn-primary">Register</button>
                        </div>
                    </form>
                     <span id="close"><i class="fas fa-times"></i></span>
                </div>
            </div>
        </div>
	</div>
<!-- end of signup -->


	

<script src="<?php echo base_url('assets/js/function.js') ?>" type="text/javascript"></script>

	
<script type="text/javascript">
	$(document).ready(function() {
		$(document).on('click', '#close', function(event) {
			event.preventDefault();
			$('.sign').removeClass('bg-active');
			/* Act on the event */
		});
		$(document).on('click', '#signup', function(event) {
			event.preventDefault();
			$('.sign').addClass('bg-active');
			/* Act on the event */
		});	
	});
</script>

<script type="text/javascript">

	var sign = document.querySelector(".sign");
	var fname = document.getElementById('fname');
	var lname = document.getElementById('lname');
	var user = document.getElementById('user');
	var pass = document.getElementById('pass');
	var log = document.querySelector(".login");


	//handler
	document.addEventListener('keyup',signup_exit,false);
	document.addEventListener('keyup',log_exit,false);


	function signup_exit(btn) {
		if (btn.charCode == 27 || btn.keyCode == 27) {
			sign.classList.remove('bg-active');
			fname.value="";
			lname.value="";
			user.value="";
			pass.value="";
		}
	}

	function log_exit(btn){
		if (btn.charCode == 27 || btn.keyCode == 27) {
			log.classList.remove('bg-active');
			user.value="";
			pass.value="";
		}
	}

</script>

</body>
</html>


